// TODO:
function attachEvents() {
    let BASE_URL = "http://localhost:3030/jsonstore/tasks/"

    // task inputs //

    let title = document.getElementById("title");
    let description = document.getElementById("description");

    // buttons //
    let loadBtn = document.getElementById("load-board-btn");
    let addTaskBtn = document.getElementById("create-task-btn");

    // sections //
    let allSections = {
        ToDo: document.querySelector("#todo-section .task-list"),
        InProgress: document.querySelector("#in-progress-section .task-list"),
        CodeReview: document.querySelector("#code-review-section .task-list"),
        Done: document.querySelector("#done-section .task-list"),
    }

    loadBtn.addEventListener("click", loadHandler);
    addTaskBtn.addEventListener("click", addHandler);


    function loadHandler() {
        allSections["ToDo"].innerHTML = "";
        allSections["InProgress"].innerHTML = "";
        allSections["CodeReview"].innerHTML = "";
        allSections["Done"].innerHTML = "";
        fetch(BASE_URL)
            .then((getResult) => getResult.json())
            .then((getData) => {
                let dataValues = Object.values(getData);
                for (const currentObj of dataValues) {
                    addELement(currentObj)
                }
            })
            .catch((error) => errorHandler(error))
    }


    function addHandler() {
        let postBody = {
            title: title.value,
            description: description.value,
            status: 'ToDo'
        }

        let httpHeaders = {
            method: "POST",
            body: JSON.stringify(postBody)
        }

        fetch(BASE_URL, httpHeaders)
            .then((postResult) => {
                loadHandler();
            })
            .catch((error) => errorHandler(error))
    }

    function addELement(currentObject) {
        let btnContent = {
            ToDo: "Move to In Progress",
            InProgress: "Move to Code Review",
            CodeReview: "Move to Done",
            Done: "Close",
        }

        let newLi = document.createElement("li");
        newLi.className = "task";
        let currentStatus = currentObject.status.split(" ").join("");

        newLi.innerHTML =
            `<h3>${currentObject.title}</h3>
            <p>${currentObject.description}</p>
            <button>${btnContent[currentStatus]}</button>
            `
        newLi.id = currentObject._id;
        allSections[currentStatus].appendChild(newLi)
        let moveBtn = newLi.getElementsByTagName("button")[0];
        moveBtn.addEventListener("click", moveHandler)

        title.value = "";
        description.value = "";
    }

    function moveHandler() {
        let currentSectionId = this.parentNode.parentNode.parentNode.id;
        let currentElementId = this.parentNode.id;
        let newStatus = null;

        if (currentSectionId === "todo-section") {
            newStatus = "In Progress";
        } else if (currentSectionId === "in-progress-section") {
            newStatus = "Code Review";
        } else if (currentSectionId === "code-review-section") {
            newStatus = "Done";
        } else if (currentSectionId === "done-section") {
            newStatus = "DELETE"
        }

        if (newStatus === "DELETE") {
            fetch(`${BASE_URL}${currentElementId}`, {
                method: newStatus
            })
                .then(() => {
                    loadHandler();
                })
                .catch((error) => errorHandler(error))

        } else {
            let httpHeaders = {
                method: "PATCH",
                body: JSON.stringify({
                    status: newStatus
                }),
            }

            fetch(`${BASE_URL}${currentElementId}`, httpHeaders)
                .then(() => {
                    loadHandler()
                })
                .catch((error) => errorHandler(error))
        }

    }

    function errorHandler(error) {
        console.error(error)
    }
}

attachEvents();