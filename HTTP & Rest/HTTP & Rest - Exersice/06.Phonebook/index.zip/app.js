function attachEvents() {
    const GET_POST_URL = "http://localhost:3030/jsonstore/phonebook/";
    const DELETE_URL = "http://localhost:3030/jsonstore/phonebook/";
    const loadBtn = document.getElementById("btnLoad");
    const createBtn = document.getElementById("btnCreate");
    const personInput = document.getElementById("person");
    const phoneInput = document.getElementById("phone");
    const resultUl = document.getElementById("phonebook");

    loadBtn.addEventListener("click", loadEventHandler);
    createBtn.addEventListener("click", createEventHandler);


    function loadEventHandler() {
        resultUl.innerHTML = "";
        fetch(GET_POST_URL)
            .then((getResult) => getResult.json())
            .then((getData) => {
                for ([key, { person, phone, _id}] of Object.entries(getData)) {
                    let newLi = document.createElement("li");
                    let newDeleteBtn = document.createElement("button");
                    newDeleteBtn.textContent = "Delete";
                    newLi.id = "phonebook";
                    newLi.textContent = `${person}: ${phone}`;
                    newLi.className = key
                    newLi.appendChild(newDeleteBtn);
                    resultUl.appendChild(newLi);
                    newDeleteBtn.addEventListener("click", deleteEventHandler);
                }
            })
            .catch(() => {
                console.error("Error on get request")
            })
    }

    function deleteEventHandler(event) {
        let btnElement = event.target;
        let currentKey = btnElement.parentNode.className;
        fetch(`${DELETE_URL}${currentKey}`, {
            method: "delete"
        })
        .then(() => {
            btnElement.parentNode.remove();
            loadBtn.click()
        })
        .catch(() => {
            console.error("Error on delete request")
        })
    }

    function createEventHandler() {
        let postInformation = {
            person: personInput.value,
            phone: phoneInput.value,
        }

        fetch(GET_POST_URL, {
            method: "post",
            body: JSON.stringify(postInformation)
        })
        .then(() =>{
            loadEventHandler()
            personInput.value = "";
            phoneInput.value = "";
        })
        .catch(() => {
            console.error("error on post request")
        })

    }
}

attachEvents();